package com.example.case_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Case4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
