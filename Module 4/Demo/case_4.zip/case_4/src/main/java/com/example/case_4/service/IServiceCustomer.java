package com.example.case_4.service;

import com.example.case_4.entity.Customer;
import org.springframework.stereotype.Service;


public interface IServiceCustomer extends IService<Customer> {

}
