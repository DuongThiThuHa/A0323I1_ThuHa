package com.example.case_4.service;

import com.example.case_4.entity.CustomerCategory;
import org.springframework.stereotype.Service;


public interface IServiceCustomerCategory extends IService<CustomerCategory> {
}
