package codegym.vn.service;

import codegym.vn.entity.Category;

public interface CategoryService extends Service<Category> {
}
